# comprobar los argumentos

if [ $# -ne 2 ]; then
  echo "Uso: $0 fichero_stats1 fichero_stats2"
  exit 1
fi

# input 1 , media y desviacion tipica 1
# input 2 , media y desviacion tipica 2


# lee la primera linea del fichero 1
linea1=$(head -n 1 "$1")
# lee la segunda linea del fichero 1
linea3=$(head -n 2 "$1" | tail -n 1)
# lee primera linea del fichero 2
linea2=$(head -n 1 "$2")
# lee segunda linea del fichero 2
linea4=$(head -n 2 "$2" | tail -n 1)

# calcula el valor t de student
# t = (media1 - media2) / sqrt( (desviacion1^2 / n1) + (desviacion2^2 / n2) )
# n1 y n2 son el numero de muestras de cada fichero
n1=16
n2=16
media1=$(echo "$linea1" | cut -d ':' -f 2)
media2=$(echo "$linea2" | cut -d ':' -f 2)
desviacion1=$(echo "$linea3" | cut -d ':' -f 2)
desviacion2=$(echo "$linea4" | cut -d ':' -f 2)

t=$(echo "($media1 - $media2) / sqrt( ($desviacion1^2 / $n1) + ($desviacion2^2 / $n2) )" | bc -l)
# printear los datos de media y desviaciones
echo "$media1"
echo "$media2"
echo "$desviacion1"
echo "$desviacion2"
echo $t


